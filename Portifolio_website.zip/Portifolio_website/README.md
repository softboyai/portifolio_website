# Professional Portfolio Website Guide

## Overview
This guide will help you create a professional portfolio website using HTML, CSS, and JavaScript. The portfolio is designed specifically for Business Information Systems students seeking internship opportunities.

## Downloading the Project Source Code

### Method 1: Direct Download
1. Visit the project repository: `https://github.com/softboyai/portfolio_website`
2. Click the green "Code" button
3. Select "Download ZIP"
4. Extract the ZIP file to your desired location
5. Open the folder in Visual Studio Code

### Method 2: Using Git (Recommended)
1. Install Git from: https://git-scm.com/downloads
2. Open terminal or command prompt
3. Navigate to your desired directory:
   ```bash
   # Windows
   cd C:\Users\YourUsername\Desktop

   # Mac/Linux
   cd ~/Desktop
   ```
4. Clone the repository:
   ```bash
   git clone https://github.com/softboyai/portfolio_website.git
   ```
5. Navigate into the project folder:
   ```bash
   cd portfolio_website
   ```

### Method 3: Manual Setup
If you prefer to start from scratch:
1. Create a new folder named `portfolio_website`
2. Download the following files:
   - index.html: `raw.githubusercontent.com/yourusername/portfolio_website/main/index.html`
   - styles.css: `raw.githubusercontent.com/yourusername/portfolio_website/main/styles.css`
   - script.js: `raw.githubusercontent.com/yourusername/portfolio_website/main/script.js`
3. Save all files in your `portfolio_website` folder

### Running the Project
1. Using Visual Studio Code:
   - Install the "Live Server" extension
   - Right-click on `index.html`
   - Select "Open with Live Server"

2. Manual Method:
   - Double-click `index.html` to open in your browser
   - Note: Some features may require a live server

### Project Files Overview
```
portfolio_website/
├── index.html          # Main HTML file with website structure
├── styles.css         # CSS styling and animations
├── script.js         # JavaScript for interactivity
├── profile.jpg       # Your profile picture (add your own)
└── README.md         # This guide
```

## Step-by-Step Implementation Guide

### 1. Setting Up Your Development Environment

#### Required Tools:
- Text Editor (Recommended: Visual Studio Code)
- Web Browser (Chrome or Firefox)
- Basic understanding of HTML, CSS, and JavaScript

#### VS Code Extensions to Install:
- Live Server
- HTML CSS Support
- Auto Rename Tag
- Prettier - Code formatter

### 2. Creating the Basic Structure

1. Create a new folder named `portfolio_website`
2. Create the following files:
   - index.html
   - styles.css
   - script.js

### 3. HTML Structure (index.html)

The HTML file is divided into several key sections:

#### Header Section
```html
<header>
    <nav>
        <div class="logo">Your Initials</div>
        <ul>
            <li><a href="#about">About</a></li>
            <li><a href="#education">Education</a></li>
            <li><a href="#skills">Skills</a></li>
            <li><a href="#projects">Projects</a></li>
            <li><a href="#contact">Contact</a></li>
        </ul>
        <div class="menu-btn">
            <i class="fas fa-bars"></i>
        </div>
    </nav>
</header>
```

#### Profile Section
```html
<section id="intro">
    <div class="container">
        <div class="profile-image">
            <img src="profile.jpg" alt="Your Name">
        </div>
        <div class="intro-text">
            <h1>Your Name</h1>
            <h2>Business Information Systems Student</h2>
            <p>Seeking Internship Opportunities</p>
        </div>
    </div>
</section>
```

### 4. Styling Guide (styles.css)

#### Color Scheme
The website uses a professional color palette defined in CSS variables:
```css
:root {
    --primary-color: #2c3e50;    /* Dark Blue */
    --secondary-color: #3498db;   /* Light Blue */
    --accent-color: #e74c3c;      /* Red */
    --text-color: #333;          /* Dark Gray */
    --light-bg: #f5f6fa;         /* Light Background */
    --white: #ffffff;            /* White */
}
```

#### Key Styling Features:
1. **Responsive Design**
   - Mobile-first approach
   - Breakpoint at 768px for mobile devices
   - Flexible grid layouts

2. **Project Cards**
   - Each project card has a unique color scheme
   - Hover effects with smooth transitions
   - Icons using Font Awesome
   - Gradient backgrounds

3. **Profile Image**
   - Circular frame with white border
   - Shadow effect
   - Hover zoom animation

### 5. Adding Your Content

#### Profile Picture
1. Take a professional photo or use an existing one
2. Save it as "profile.jpg"
3. Recommended specifications:
   - Square format (minimum 400x400px)
   - Professional attire
   - Neutral background
   - Well-lit face

#### Personal Information
Update the following sections in index.html:
1. Change "Your Name" to your actual name
2. Update contact information
3. Modify education details
4. Add your skills
5. Include your projects

### 6. Project Section Customization

Each project card has unique styling:
```css
.project-card:nth-child(1) {
    border-top-color: #e74c3c;    /* Red */
    background: linear-gradient(to bottom right, #ffffff, #fff5f5);
}

.project-card:nth-child(2) {
    border-top-color: #2ecc71;    /* Green */
    background: linear-gradient(to bottom right, #ffffff, #f0fff4);
}

.project-card:nth-child(3) {
    border-top-color: #f1c40f;    /* Yellow */
    background: linear-gradient(to bottom right, #ffffff, #fffff0);
}
```

### 7. Mobile Responsiveness

Test your website on different devices:
1. Use browser developer tools (F12)
2. Check different screen sizes
3. Test navigation menu on mobile
4. Verify all hover effects
5. Ensure images scale properly

### 8. Common Issues and Solutions

1. **Images Not Loading**
   - Check file path is correct
   - Verify image file exists
   - Ensure proper file extension

2. **Mobile Menu Not Working**
   - Check JavaScript is properly linked
   - Verify class names match
   - Test click events

3. **Layout Breaking**
   - Check media queries
   - Verify container widths
   - Test different screen sizes

### 9. Enhancement Ideas

1. **Additional Sections**
   - Add a blog section
   - Include certificates
   - Add testimonials

2. **Visual Improvements**
   - Add more animations
   - Include project screenshots
   - Add video demonstrations

3. **Functionality**
   - Add contact form
   - Include download CV button
   - Add project filtering

### 10. Best Practices

1. **Code Organization**
   - Use meaningful class names
   - Comment your code
   - Keep files organized

2. **Performance**
   - Optimize images
   - Minimize CSS/JS
   - Use appropriate image sizes

3. **Accessibility**
   - Include alt text for images
   - Use semantic HTML
   - Ensure proper contrast

### 11. Testing Checklist

- [ ] All links work correctly
- [ ] Images load properly
- [ ] Mobile menu functions
- [ ] Hover effects work
- [ ] Contact links are correct
- [ ] Forms submit properly
- [ ] No horizontal scroll on mobile
- [ ] All text is readable
- [ ] Colors have good contrast
- [ ] Smooth scrolling works

## Resources

### Learning Materials
- MDN Web Docs: https://developer.mozilla.org
- W3Schools: https://www.w3schools.com
- CSS-Tricks: https://css-tricks.com

### Tools
- Font Awesome Icons: https://fontawesome.com
- Google Fonts: https://fonts.google.com
- Color Palettes: https://coolors.co

### Image Resources
- Unsplash: https://unsplash.com
- Pexels: https://pexels.com
- Optimizilla: https://imagecompressor.com

## Support
If you encounter any issues or need help, please:
1. Check the troubleshooting section
2. Review the code comments
3. Consult the provided resources
4. Ask your me for guidance

## Contributing
Feel free to suggest improvements or report issues to make this template better for future interns.

---
Created with ❤️ for Mount Kigali University  Students

## Troubleshooting Download Issues

### Common Download Problems
1. **ZIP file won't extract**
   - Try using 7-Zip or WinRAR
   - Check if you have write permissions
   - Try extracting to a different location

2. **Git clone fails**
   - Verify Git is installed: `git --version`
   - Check your internet connection
   - Ensure you have the correct repository URL

3. **Files not downloading**
   - Check your internet connection
   - Try a different browser
   - Use a download manager

### Getting Help
If you encounter issues downloading the project:
1. Check the troubleshooting section above
2. Contact  supervisor
3. Visit the project's issues page on GitHub
4. Ask for help in the class discussion forum
